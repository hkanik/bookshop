<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[
    'uses' => 'MainController@index',
    'as'=> '/'
]);
Route::get('/home/category/{id}',[
    'uses' => 'MainController@category',
    'as'=> 'home-category'
]);

Route::get('/home/book-details/{id}',[
    'uses' => 'MainController@bookDetails',
    'as'=> 'book-details'
]);

Route::get('/home',[
    'uses' => 'LinkController@home',
    'as'=> 'home'
]);

Route::get('/about',[
    'uses' => 'LinkController@about',
    'as'=> 'about'
]);

Route::get('/art',[
    'uses' => 'LinkController@art',
    'as'=> 'art'
]);

Route::get('/bio&memories',[
    'uses' => 'LinkController@bio_memories',
    'as'=> 'bio_memories'
]);
Route::get('/business&finance',[
    'uses' => 'LinkController@business_finance',
    'as'=> 'business_finance'
]);

Route::get('/childrensBooks',[
    'uses' => 'LinkController@childrensBooks',
    'as'=> 'childrensBooks'
]);

Route::get('/contact',[
    'uses' => 'LinkController@contact',
    'as'=> 'contact'
]);

Route::get('/cookBooks',[
    'uses' => 'LinkController@cookBooks',
    'as'=> 'cookBooks'
]);

Route::get('/drama',[
    'uses' => 'LinkController@drama',
    'as'=> 'drama'
]);

Route::get('/fiction&fantasy',[
    'uses' => 'LinkController@fiction_fantasy',
    'as'=> 'fiction_fantasy'
]);

Route::get('/health&fitness',[
    'uses' => 'LinkController@health_fitness',
    'as'=> 'health_fitness'
]);

Route::get('/history',[
    'uses' => 'LinkController@history',
    'as'=> 'history'
]);

Route::get('/horror',[
    'uses' => 'LinkController@horror',
    'as'=> 'horror'
]);

Route::get('/photography',[
    'uses' => 'LinkController@photography',
    'as'=> 'photography'
]);

Route::get('/productDetails',[
    'uses' => 'LinkController@productDetails',
    'as'=> 'productDetails'
]);



//admin routes
Auth::routes();

Route::get('/admin/dashboard',[
    'uses' => 'HomeController@index',
    'as'=> 'admin-dashboard'
]);

//category
Route::get('/category/add',[
    'uses' => 'CategoryController@index',
    'as'=> 'add-category'
]);

Route::post('/category/new',[
    'uses' => 'CategoryController@saveCategory',
    'as'=> 'new-category'
]);
Route::get('/category/manage',[
    'uses' => 'CategoryController@manageCategory',
    'as'=> 'manage-category'
]);

Route::get('/category/unpublished/{id}',[
    'uses' => 'CategoryController@unpublishedCategory',
    'as'=> 'unpublished-category'
]);
Route::get('/category/published/{id}',[
    'uses' => 'CategoryController@publishedCategory',
    'as'=> 'published-category'
]);

Route::get('/category/edit/{id}',[
    'uses' => 'CategoryController@editCategory',
    'as'=> 'edit-category'
]);
Route::post('/category/update',[
    'uses' => 'CategoryController@updateCategory',
    'as'=> 'update-category'
]);
Route::get('/category/delete/{id}',[
    'uses' => 'CategoryController@deleteCategory',
    'as'=> 'delete-category'
]);


//add books
Route::get('/books/add-books',[
    'uses' => 'BooksController@index',
    'as'=> 'add-books'
]);

Route::post('/books/new-book',[
    'uses' => 'BooksController@saveBook',
    'as'=> 'new-book'
]);

Route::get('/books/manage-book',[
    'uses' => 'BooksController@manageBook',
    'as'=> 'manage-books'
]);

Route::get('/book/unpublished/{id}',[
    'uses' => 'BooksController@unpublishedBook',
    'as'=> 'unpublished-book'
]);
Route::get('/book/published/{id}',[
    'uses' => 'BooksController@publishedBook',
    'as'=> 'published-book'
]);


Route::get('/books/edit/{id}',[
    'uses' => 'BooksController@editBook',
    'as'=> 'edit-book'
]);
Route::post('/books/update',[
    'uses' => 'BooksController@updateBook',
    'as'=> 'update-book'
]);
Route::get('/books/delete/{id}',[
    'uses' => 'BooksController@deleteBook',
    'as'=> 'delete-book'
]);