<section class="marquee">
    <div class="container marquee_text">
        <marquee>welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Buy your favourite books &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Buy your favourite books</marquee>
    </div>
</section>

<section>
    <nav class="navbar navbar-expand-lg navbar-light custom_nav">
        <div class="container">
            <div class="logo_bar">
                <div class="site_logo">
                    <a class="navbar-brand" href="<?php echo e(route('/')); ?>">
                        <img class="sitelogo" src="<?php echo e(asset('/')); ?>frontEnd/images/Bookshop-Logo.png" alt="logo">
                    </a>
                </div>

                <div class="search_bar">
                    <form class="form-inline my-2 my-lg-0 mr-auto">
                        <input class="form-control mr-sm-2" type="search" size="30" placeholder="Search Here" aria-label="Search">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>

            <div class="nav_menu">
                <ul>
                    <li><a href="">Log In</a></li>
                    <li><a href="#"><span></span></a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">contact us</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">abouts us</a></li>
                </ul>
            </div>
            <div class="clr"></div>
        </div>
    </nav>
</section>
<!--  First Part End  -->

<!--  Second Part Start  -->
<section>
    <div class="menu_part">
        <div class="container">
            <div class="menu">
                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('home-category',['id'=>$category->id])); ?>"><?php echo e($category->category_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                            
                                
                                    
                                
                            
                        

                </ul>
            </div>
            <div class="clr"></div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/include/header.blade.php ENDPATH**/ ?>