<?php $__env->startSection('body'); ?>
    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/thumb-1920-26102.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/thumb-1920-421124.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/wp2036967.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/wp2037001.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/wp2036946.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/thumb-1920-375332.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>I love this Idea</h2>
                            <p>Cover Up Front of Book and Leave Summary.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--  Third Part End -->

    <!--  Fourth Part Start  -->

    <section>
        <div class="col-lg-12 work_part">
            <div class="container">
                <div class="section_heading">
                    <h2>welcome to book store</h2>
                    <p>“Do not insult a writer by asking him questions related to books written by someone else. If you are not reading the books written by the author you question, you are an hypocrite and a cynical, and you deserve no answers.”</p>
                </div>
            </div>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="work_item">
                <div class="venobox"><img src="<?php echo e(asset($category->category_image)); ?>" alt=""></div>
                <a href="<?php echo e(route('home-category',['id'=>$category->id])); ?>" target="_blank">
                    <div class="overlay">
                        <div class="overlay_text">
                            <h2><?php echo e($category->category_name); ?></h2>
                            <p></p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="clr"></div>
        </div>
    </section>

    <!--  Fourth Part End  -->

    <!--  Fifth part Start  -->

    <section>
        <div class="newsletter">
            <div class="container">
                <div class="section_heading">
                    <h2>Quotes &nbsp;&nbsp; & &nbsp;&nbsp; Newsletter</h2>
                </div>
            </div>
            <div class="newsletter_left" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/book_coffee_bed_shadow.jpg)">
                <div class="col-lg-12 newsletter_text">
                    <div class="newsletter_text_inn">
                        <p>“Do not insult a writer by asking him questions related to books written by someone else. If you are not reading the books written by the author you question, you are an hypocrite and a cynical, and you deserve no answers.”</p>
                        <h1>-----------</h1>
                        <h2>Robin Sacredfire</h2>
                    </div>

                    <div class="newsletter_text_inn">
                        <p>"The probability of finding a particular book increases in relation to the clarity of the store's focus, the diligence and shrewdness of the bookseller, and the size of the business."</p>
                        <h1>-----------</h1>
                        <h2>Gabriel Zaid</h2>
                    </div>
                </div>

            </div>
            <div class="newsletter_right" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/coffee_book_windowsill.jpg)">
                <div class="col-lg-12 newsletter_text">
                    <div class="newsletter_text_inn">
                        <h2>newletter</h2>
                        <p>Subscribe to our newsletter to get the most recent news and updates. Also we occasionally throw some free book(s).</p>
                        <form action="" method="post">
                            <input id="logmail" type="email" placeholder="Enter your Email" size="30">
                            <input class="submit_button" type="submit" value="Submit">
                        </form>
                    </div>
                </div>
            </div>
            <div class="clr"></div>
        </div>
    </section>

    <!--  Fifth part End  -->

    <!--  Sixth Part Start  -->

    <section>
        <div class="media_part">
            <div class="container media_part_body">

                <!------------------- deal_of_day -------------------->

                <div class="col-md-3 deal_of_day">
                    <p>deal of day<br>-------</p>
                    <?php $__currentLoopData = $bookshelf1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($i=1); ?>
                    <div class="deal_of_day_inn">
                        <div class="deal_of_day_one">
                            <h1><?php echo e($i++); ?>.</h1>
                        </div>
                        <div class="deal_of_day_two">
                            <a href="<?php echo e(route('book-details',['id'=>$book->id])); ?>">
                                <img src="<?php echo e(asset($book->book_image)); ?>" alt="">
                            </a>
                        </div>
                        <div class="deal_of_day_three">
                            <h2><?php echo e($book->book_name); ?></h2>
                            <h3>By: <?php echo e($book->author_name); ?></h3>
                            <h4>৳ <?php echo e($book->book_price); ?></h4>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <!------------------- recent_and_popular -------------------->

                <div class="col-md-3 recent_and_popular">
                    <p>recent and popular<br>-------</p>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $bookshelf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="recent_and_popular_inn">
                        <div class="recent_and_popular_one">
                            <h1><?php echo e($i++); ?>.</h1>
                        </div>
                        <div class="recent_and_popular_two">
                            <a href="<?php echo e(route('book-details',['id'=>$book->id])); ?>">
                                <img src="<?php echo e(asset($book->book_image)); ?>" alt="">
                            </a>
                        </div>
                        <div class="recent_and_popular_three">
                            <h2><?php echo e($book->book_name); ?></h2>
                            <h3>By: <?php echo e($book->author_name); ?></h3>
                            <h4>৳ <?php echo e($book->book_price); ?></h4>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-------------------- best_seller ------------------->

                <div class="col-md-3 best_seller">
                    <p>Best Seller<br>-------</p>
                    <?php $__currentLoopData = $bookshelf2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($i=1); ?>
                    <div class="best_seller_inn">
                        <div class="best_seller_one">
                            <h1><?php echo e($i++); ?>.</h1>
                        </div>
                        <div class="best_seller_two">
                            <a href="<?php echo e(route('book-details',['id'=>$book->id])); ?>">
                                <img src="<?php echo e(asset($book->book_image)); ?>" alt="">
                            </a>
                        </div>
                        <div class="best_seller_three">
                            <h2><?php echo e($book->book_name); ?></h2>
                            <h3>By: <?php echo e($book->author_name); ?></h3>
                            <h4>৳ <?php echo e($book->book_price); ?></h4>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-------------------- top_books ------------------->

                <div class="col-md-3 top_books">
                    <p>top book<br>-------</p>
                    <?php $__currentLoopData = $bookshelf3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($i=1); ?>
                    <div class="top_books_inn">
                        <div class="top_books_one">
                            <h1><?php echo e($i++); ?>.</h1>
                        </div>
                        <div class="top_books_two">
                            <h2><?php echo e($book->book_name); ?></h2>
                            <h3><?php echo e($book->author_name); ?></h3>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/home.blade.php ENDPATH**/ ?>