  <!--    Preloader End  -->

    <!--  First Part Start  -->
    
    <!--  Second Part End  -->

    <!--  Third Part Start  -->
<?php $__env->startSection('body'); ?>
    <section>
        <div class="about">
            <div class="container">

                <div class="about_left">
                    <img src="<?php echo e(asset('/')); ?>frontEnd/images/IMG_Abir.jpg" alt="">
                    <h1>Name: S. M. Ashraf Siddiqui</h1>
                    <h1>Daffodil International University</h1>
                </div>

                <div class="about_right">
                    <img src="<?php echo e(asset('/')); ?>frontEnd/images/IMG_Urmi.jpg" alt="">
                    <h1>Name: Urmi Roy</h1>
                    <h1>Daffodil International University</h1>
                </div>

            </div>
            <div class="clr"></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
    <!--  Third Part End  -->

    <!--  Seventh Part Start  -->

<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/about.blade.php ENDPATH**/ ?>