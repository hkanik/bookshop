;

<?php $__env->startSection('body'); ?>
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Edit Books Category</h2>
        </div>
    </div>

    <div class="col-lg-6 offset-lg-1" style="margin-top: 20px; ">
        <div>
            <div class="block-body">
                <form method="post" action="<?php echo e(route('update-category')); ?>">
                    <h3 class="text-center text-warning"><?php echo e(Session::get('message1')); ?></h3>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-control-label">Category Name</label>
                        <input type="text" name="category_name" class="form-control" value="<?php echo e($category->category_name); ?>" required>
                        <input type="hidden" name="category_id" class="form-control" value="<?php echo e($category->id); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Category Description</label>
                        <textarea class="form-control" name="category_description" id="" cols="30" rows="5"><?php echo e($category->category_description); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Publication Status</label> &nbsp;
                        <input type="radio" name="publication_status" value="1" required <?php echo e($category->publication_status == 1? 'checked':''); ?>> Published &nbsp;
                        <input type="radio" name="publication_status" value="0" required <?php echo e($category->publication_status == 0? 'checked':''); ?>> Unpublished
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" name="submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/backEnd/admin/category/edit-category.blade.php ENDPATH**/ ?>