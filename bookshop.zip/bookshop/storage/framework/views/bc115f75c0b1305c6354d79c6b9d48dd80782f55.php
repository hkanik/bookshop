<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bookshop- Books Category</title>
    <link rel="icon" href="<?php echo e(asset('/')); ?>frontEnd/images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/fontawesome.all.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/booklist.css">
</head>

<body>
<!--  First Part Start  -->
<?php echo $__env->make('frontEnd.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--  Second Part End  -->

<!--  Third Part Start  -->
<?php echo $__env->yieldContent('body'); ?>

<!--  Fourth Part End  -->

<!--  Fifth Part Start  -->

<?php echo $__env->make('frontEnd.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--backtop end-->



<script src="<?php echo e(asset('/')); ?>frontEnd/js/jquery-1.12.4.min.js"></script>
<script src="<?php echo e(asset('/')); ?>frontEnd/js/popper.min.js"></script>
<script src="<?php echo e(asset('/')); ?>frontEnd/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>frontEnd/js/slick.min.js"></script>
<script src="<?php echo e(asset('/')); ?>frontEnd/js/script.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/master2.blade.php ENDPATH**/ ?>