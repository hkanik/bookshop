
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bookshop-Business & Finance Books</title>
    <link rel="icon" href="<?php echo e(asset('/')); ?>frontEnd/images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/fontawesome.all.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontEnd/css/booklist.css">
</head>

<body>

	<section class="marquee">
        <div class="container marquee_text">
            <marquee>welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Buy your favourite books &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Buy your favourite books</marquee>
        </div>
    </section>

    <!--  First Part Start  -->
    <section>
        <nav class="navbar navbar-expand-lg navbar-light custom_nav">
            <div class="container">
                <div class="logo_bar">
                    <div class="site_logo">
                        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                            <img class="sitelogo" src="<?php echo e(asset('/')); ?>frontEnd/images/Bookshop-Logo.png" alt="logo">
                        </a>
                    </div>

                    <div class="search_bar">
                        <form class="form-inline my-2 my-lg-0 mr-auto">
                            <input class="form-control mr-sm-2" type="search" size="30" placeholder="Search Here" aria-label="Search">
                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                        </form>
                    </div>
                </div>

                <div class="nav_menu">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">log out</a></li>
                        <li><a href="#"><span></span></a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">contact us</a></li>
                        <li><a href="<?php echo e(route('about')); ?>">abouts us</a></li>
                    </ul>
                </div>
                <div class="clr"></div>
            </div>
        </nav>
    </section>
    <!--  First Part End  -->

    <!--  Second Part Start  -->
    <section>
        <div class="menu_part">
            <div class="container">
                <div class="menu">
                    <ul>
                        <li><a href="<?php echo e(route('art')); ?>">art</a></li>
                        <li><a href="<?php echo e(route('photography')); ?>">photography</a></li>
                        <li><a href="<?php echo e(route('bio_memories')); ?>">bio & memories</a></li>
                        <li><a href="<?php echo e(route('business_finance')); ?>">business & Finance</a></li>
                        <li><a href="<?php echo e(route('childrensBooks')); ?>">childern's book</a></li>
                        <li><a href="<?php echo e(route('cookBooks')); ?>">cook books</a></li>
                        <li><a href="<?php echo e(route('drama')); ?>">drama</a></li>
                        <li><a href="#">more&nbsp;&nbsp;<i class="fas fa-angle-down"></i></a>
                            <ul>
                                <li><a href="<?php echo e(route('fiction_fantasy')); ?>">fiction & fantasy</a></li>
                                <li><a href="<?php echo e(route('history')); ?>">history</a></li>
                                <li><a href="<?php echo e(route('health_fitness')); ?>">health & fitness</a></li>
                                <li><a href="<?php echo e(route('horror')); ?>">horror</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="clr"></div>
            </div>
        </div>
    </section>
    <!--  Second Part End  -->

    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/Books_507x313_SHP_Homepg.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>Busines & Finance</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--  Third Part Start  -->

    <section>
        <div class="container books">
            <div class="col-lg-3 books_inn_one">
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_two">
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_three">
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_four">
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>
        </div>
    </section>

    <!--  Third Part End  -->

    <!--  Fourth Part Start  -->

    <section>
        <div class="contact_part">
            <div class="container contact_part_inn">
                <div class="col-lg-3 contact_part_inn_contact">
                    <h1>contact</h1>
                    <h2>ashraf@bookshopbd.com<br>001 (407) 901-6400<br>Made in Bangladesh </h2>
                    <a href="https://www.facebook.com/ashraf.siddiqui.abir" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/abir_siddiqui" target="_blank"><i class="fab fa-twitter"></i></a>
                    <i class="fab fa-google-plus-g"></i>
                </div>

                <div class="col-lg-3 contact_part_inn_find">
                    <h1>find</h1>
                    <div class="contact_part_inn_find_items">
                        <h2>Columns</h2>
                        <h2>Recipes</h2>
                        <h2>Contents</h2>
                        <h2>Hotline</h2>
                        <h2>Shop</h2>
                        <h2>The piglet</h2>
                        <h2>Sitemap</h2>
                    </div>
                </div>

                <div class="col-lg-3 contact_part_inn_shop">
                    <h1>shop</h1>
                    <div class="contact_part_inn_shop_items">
                        <h2>My Orders</h2>
                        <h2>Shop Cpllections</h2>
                        <h2>Gift Cards</h2>
                        <h2>Get Help</h2>
                        <h2>FAQ</h2>
                        <h2>Refer Friends, Get $20</h2>
                        <h2>Affilliate Program</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--  Fourth Part End  -->


    <!--  Fifth Part Start  -->

    <section>
        <div class="footer_part">
            <div class="container footer_part_inn">
                <h1>Copyright 2019 &copy; bookshopbd.com</h1>
            </div>
        </div>
    </section>

    <!--  Fifth Part End  -->




    <!--backtop start-->
    <section>
        <div class="backtop">
            <i class="fas fa-arrow-up"></i>
        </div>
    </section>
    <!--backtop end-->




    <script src="<?php echo e(asset('/')); ?>frontEnd/js/jquery-1.12.4.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>frontEnd/js/popper.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>frontEnd/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>frontEnd/js/slick.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>frontEnd/js/script.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/business&finance.blade.php ENDPATH**/ ?>