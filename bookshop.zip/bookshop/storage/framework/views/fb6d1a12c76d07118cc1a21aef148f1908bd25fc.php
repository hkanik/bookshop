<?php $__env->startSection('body'); ?>
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Manage Books Category</h2>
        </div>
    </div>

    <div class="col-lg-10 offset-lg-1" style="margin-top: 20px; ">
        <h3 class="text-center text-success"><?php echo e(Session::get('message1')); ?></h3>
        <h3 class="text-center text-danger"><?php echo e(Session::get('message')); ?></h3>
        <table class="table">
            <tr>
                <th>Serial No.</th>
                <th>Category Name</th>
                <th>Category Description</th>
                <th>Publication Status</th>
                <th>Action</th>
            </tr>
            <?php ($i=1); ?>
            <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($category-> category_name); ?></td>
                <td><?php echo e($category-> category_description); ?></td>
                <td><?php echo e($category-> publication_status == 1?'Published':'Unpublished'); ?></td>
                <td>
                    <?php if($category->publication_status == 1): ?>
                        <a href="<?php echo e(route('unpublished-category',['id'=>$category->id])); ?>" class="btn btn-success">
                            <i class="fas fa-arrow-up"></i>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('published-category',['id'=>$category->id])); ?>" class="btn btn-danger">
                            <i class="fas fa-arrow-down"></i>
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('edit-category',['id'=>$category->id])); ?>" class="btn btn-info">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="<?php echo e(route('delete-category',['id'=>$category->id])); ?>" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/backEnd/admin/category/manage-category.blade.php ENDPATH**/ ?>