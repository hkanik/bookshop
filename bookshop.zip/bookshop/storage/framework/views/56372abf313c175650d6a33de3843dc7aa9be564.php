<?php $__env->startSection('body'); ?>
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Add Books</h2>
        </div>
    </div>

    <div class="col-lg-6 offset-lg-1" style="margin-top: 20px; ">
        <div>
            <div class="block-body">
                <form method="post" action="<?php echo e(route('new-book')); ?>" enctype="multipart/form-data">
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-control-label">Category Name</label>
                        <select name="category_id" class="form-control" required>
                            <option>--Select Category Name--</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Name</label>
                        <input type="text" name="book_name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Author Name</label>
                        <input type="text" name="author_name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Id</label>
                        <input type="text" name="book_id" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Description</label>
                        <textarea class="form-control" name="book_description" id="" cols="30" rows="5" required></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Price</label>
                        <input type="text" name="book_price" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Quantity</label>
                        <input type="number" name="book_qnt" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Image</label><br>
                        <input type="file" name="book_image" >
                    </div>

                    <br>

                    <div class="form-group">
                        <label class="form-control-label">Book Status</label>
                        <select name="book_status" class="form-control" required>
                            <option>--Select Book Status--</option>
                                <option value="popular">Popular</option>
                                <option value="deal">Deal Of Day</option>
                                <option value="recent">Recent</option>
                                <option value="best_seller">Best Seller</option>
                                <option value="top_book">Top Book</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Publication Status</label> &nbsp;
                        <input type="radio" name="publication_status" value="1" required> Published &nbsp;
                        <input type="radio" name="publication_status" value="0" required> Unpublished
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" name="submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/backEnd/admin/books/add-books.blade.php ENDPATH**/ ?>