    
<?php $__env->startSection('body'); ?>
    <section>
        <div class="abtproduct">
            <div class="container abtproduct_inn">
                <div class="abtproduct_left">
                    <img src="<?php echo e(asset($books->book_image)); ?>" alt="">
                </div>
                <div class="abtproduct_right">
                    
                    <h1><?php echo e($books->book_name); ?></h1>

                    <h2>by: <?php echo e($books->author_name); ?></h2>

                    <h2>book ID: <?php echo e($books->book_id); ?></h2>

                    <p><?php echo e($books->book_description); ?></p>

                    <h3> $ <?php echo e($books->book_price); ?></h3>

                    <label>Quantity: </label>
                    <select>
                        <option>Select</option>

                            <?php for($i=1;$i<=5;$i++): ?>
                            <option><?php echo e($i); ?></option>
                            <?php endfor; ?>

                    </select>
                    <br><br>
                    <input type="submit" value="add to cart">
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/productdetails.blade.php ENDPATH**/ ?>