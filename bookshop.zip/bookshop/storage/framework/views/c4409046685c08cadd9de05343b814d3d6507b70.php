<?php $__env->startSection('body'); ?>
    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/Books_507x313_SHP_Homepg.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">
                        <div class="banner_text_inn">
                            <h2>Art</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--  Third Part End  -->


    <!--  Fourth Part Start  -->

    <section>
        <div class="container books">
            <div class="col-lg-3 books_inn_one">
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_one_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_two">
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_two_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_three">
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_three_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>

            <div class="col-lg-3 books_inn_four">
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Complete%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Ian Farrell</h2>
                    <h3>£ 40.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Langford's%20Basic%20Photography.jpg" alt="">
                    </a>
                    <h1>Langford's Basic Photography</h1>
                    <h2> Michael Langford</h2>
                    <h3>£ 70.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/LIFE%20Guide%20to%20Digital%20Photography.jpg" alt="">
                    </a>
                    <h1>Complete Guide to Digital Photography</h1>
                    <h2>Joe McNally</h2>
                    <h3>£ 30.00</h3>
                </div>
                <div class="books_inn_four_inn">
                    <a href="#">
                        <img src="<?php echo e(asset('/')); ?>frontEnd/images/Understanding%20Exposure,%20Fourth%20Edition.jpg" alt="">
                    </a>
                    <h1>Understanding Exposure, Fourth Edition</h1>
                    <h2>Bryan Peterson</h2>
                    <h3>£ 24.00</h3>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/art.blade.php ENDPATH**/ ?>