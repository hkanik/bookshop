<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dark Bootstrap Admin </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>bacEnd/admin/css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>bacEnd/admin/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>bacEnd/admin/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('/')); ?>bacEnd/admin/img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<body>
<div class="login-page">
    <div class="container d-flex align-items-center">
        <div class="form-holder has-shadow">
            <div class="row">
                <!-- Logo & Information Panel-->
                <div class="col-lg-6">
                    <div class="info d-flex align-items-center">
                        <div class="content">
                            <div class="logo">
                                <h1>Dashboard</h1>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        </div>
                    </div>
                </div>
                <!-- Form Panel    -->
                <div class="col-lg-6 bg-white">
                    <div class="form d-flex align-items-center">
                        <div class="content">
                            <form method="post" action="<?php echo e(route('register')); ?>" class="text-left form-validate">
                                <?php echo csrf_field(); ?>
                                <div class="form-group-material">
                                    <input id="register-username" type="text" name="username" required data-msg="Please enter your username" class="input-material">
                                    <label for="register-username" class="label-material">Username</label>
                                </div>
                                <div class="form-group-material">
                                    <input id="register-email" type="email" name="email" required data-msg="Please enter a valid email address" class="input-material">
                                    <label for="register-email" class="label-material">Email Address      </label>
                                </div>
                                <div class="form-group-material">
                                    <input id="register-password" type="password" name="password" required data-msg="Please enter your password" class="input-material">
                                    <label for="register-password" class="label-material">Password        </label>
                                </div>
                                <div class="form-group-material">
                                    <input id="register-password" type="password" name="password_confirmation" required data-msg="Please enter your password" class="input-material">
                                    <label for="register-password" class="label-material">Confirm Password</label>
                                </div>
                                
                                    
                                    
                                
                                <div class="form-group text-center">
                                    <input id="register" type="submit" name="submit" value="Register" class="btn btn-primary">
                                </div>
                            </form><small>Already have an account? </small><a href="<?php echo e(route('login')); ?>" class="signup">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- JavaScript files-->
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/popper.js/umd/popper.min.js"> </script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/chart.js/Chart.min.js"></script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('/')); ?>bacEnd/admin/js/front.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/backEnd/admin/register.blade.php ENDPATH**/ ?>