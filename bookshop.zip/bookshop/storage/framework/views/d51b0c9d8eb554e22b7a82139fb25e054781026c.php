<?php $__env->startSection('body'); ?>
    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url(<?php echo e(asset('/')); ?>frontEnd/images/Books_507x313_SHP_Homepg.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">

                        <div class="banner_text_inn">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2><?php echo e($category->category_name); ?></h2>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--  Third Part End  -->


    <!--  Fourth Part Start  -->

    <section>
        <div class="container books">
                <div class="col-lg-12 books_inn_one">
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="books_inn_one_inn">
                        <a href="<?php echo e(route('book-details',['id'=>$book->id])); ?>">
                            <img src="<?php echo e(asset($book->book_image)); ?>" alt="">
                        </a>
                        <h1><?php echo e($book->book_name); ?></h1>
                        <h2><?php echo e($book->author_name); ?></h2>
                        <h3>৳ <?php echo e($book->book_price); ?></h3>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>



        </div>
        <div style="margin-left: 45%;margin-bottom: 5%" >
            <?php echo e($books->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/category.blade.php ENDPATH**/ ?>