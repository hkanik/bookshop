<?php $__env->startSection('body'); ?>
    <section>
        <div class="container contact">
            <div class="contact_left">
                <div class="contact_left_inn">
                    <h1>contact information<br><br>------------------</h1>
                    <h2>bangladesh</h2>
                    <h3>Khagan Bazar,&nbsp;&nbsp;Ashulia. <br> Call: +880 1685 36 13 48 ,<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+880 1751 54 42 56 <br>Email: admin@bookshopbd.com</h3>

                    <a href="https://www.facebook.com/ashraf.siddiqui.abir" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/abir_siddiqui" target="_blank"><i class="fab fa-twitter"></i></a>

                    <p>We’d love to hear from you! Send us a message using the <br> form below.</p>

                    <form action="/action_page.php">
                        <input type="text" name="firstname" placeholder="First Name *" required>
                        <br>

                        <input type="text" name="lastname" placeholder="Last Name *" required>
                        <br>

                        <input type="email" name="Email" placeholder="Email *" required>
                        <br>

                        <textarea rows="4" cols="50" name="" placeholder="MESSAGE"></textarea>
                        <br><br>

                        <input type="submit" value="Send">
                    </form>
                </div>
            </div>

            <div class="contact_right">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3648.399226824979!2d90.31013850078921!3d23.875458104591964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c259fa853253%3A0xeb42feba436deb20!2sDaffodil+International+University%2C+Bangladesh!5e0!3m2!1sen!2sbd!4v1558464804408!5m2!1sen!2sbd" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/frontEnd/contact.blade.php ENDPATH**/ ?>