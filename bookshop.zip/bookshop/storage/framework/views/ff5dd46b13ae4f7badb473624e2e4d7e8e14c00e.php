<?php $__env->startSection('body'); ?>
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Edit Book</h2>
        </div>
    </div>

    <div class="col-lg-6 offset-lg-1" style="margin-top: 20px; ">
        <div>
            <div class="block-body">
                <form method="post" action="<?php echo e(route('update-book')); ?>">
                    <h3 class="text-center text-warning"><?php echo e(Session::get('message1')); ?></h3>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-control-label">Category Name</label>
                        <select name="category_id" class="form-control" required>
                            <option><?php echo e($books->category_id); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="books_id" class="form-control" value="<?php echo e($books->id); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Name</label>
                        <input type="text" name="book_name" class="form-control" value="<?php echo e($books->book_name); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Author Name</label>
                        <input type="text" name="author_name" class="form-control" value="<?php echo e($books->author_name); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Id</label>
                        <input type="text" name="book_id" class="form-control" value="<?php echo e($books->book_id); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Description</label>
                        <textarea class="form-control" name="book_description" id="" cols="30" rows="5" required><?php echo e($books->book_description); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Price</label>
                        <input type="text" name="book_price" class="form-control" value="<?php echo e($books->book_price); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Quantity</label>
                        <input type="number" name="book_qnt" class="form-control" value="<?php echo e($books->book_qnt); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Book Status</label>
                        <select name="book_status" class="form-control" required>
                            <option><?php echo e($books->book_status); ?></option>
                            <option value="popular">Popular</option>
                            <option value="deal">Deal Of Day</option>
                            <option value="recent">Recent</option>
                            <option value="best_seller">Best Seller</option>
                            <option value="top_book">Top Book</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-control-label">Publication Status</label> &nbsp;
                        <input type="radio" name="publication_status" value="1" required <?php echo e($books->publication_status == 1? 'checked':''); ?>> Published &nbsp;
                        <input type="radio" name="publication_status" value="0" required <?php echo e($books->publication_status == 0? 'checked':''); ?>> Unpublished
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" name="submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookshop\resources\views/backEnd/admin/books/edit-book.blade.php ENDPATH**/ ?>