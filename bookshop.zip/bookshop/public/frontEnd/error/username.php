<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Bookshop - User name Exists</title>
    <link rel="icon" href="images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="../css/fontawesome.all.css">
    <link rel="stylesheet" href="../css/message.css">
</head>

<style>
    body {
        background: url(../images/sad-1.jpg);
    }

</style>

<body>
    <section>
        <div class="message">
            <h1><i class="far fa-frown"></i>&nbsp;&nbsp;oops sorry !!!&nbsp;&nbsp;<i class="far fa-frown"></i></h1>
            <h2>User name already exists.&nbsp; <a href="../signup.php">Click Here</a>&nbsp; to try again please. </h2>
        </div>
    </section>

    <script src="js/bootstrap.min.js"></script>
    <script src="js/popper.min.js"></script>

</body>

</html>
