<?php

namespace App\Http\Controllers;

use App\Book;
use Illuminate\Http\Request;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $books = Book::where('publication_status',1)->count();
        $allbooks = DB::table('books')->sum('book_qnt');
        return view('backEnd.admin.admin',[
            'books'=>$books,
            'allbooks' =>$allbooks
        ]);
    }
}
