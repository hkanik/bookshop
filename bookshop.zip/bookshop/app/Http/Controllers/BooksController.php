<?php

namespace App\Http\Controllers;

use App\Book;
use App\Category;
use Illuminate\Http\Request;
use DB;

class BooksController extends Controller
{
    public function index(){
        $category = Category::where('publication_status',1)->get();
        return view('backEnd.admin.books.add-books',[
            'category'=> $category
        ]);
    }

    public function saveBook(Request $request){
        $bookImage = $request->file('book_image');
        $imgName = $bookImage->getClientOriginalName();
        $directory = 'book-image/';
        $imgeUrl = $directory.$imgName;
        $bookImage->move($directory,$imgName);

        $book = new Book();
        $book->category_id = $request->category_id;
        $book->book_name = $request->book_name;
        $book->author_name = $request->author_name;
        $book->book_id = $request->book_id;
        $book->book_description = $request->book_description;
        $book->book_price = $request->book_price;
        $book->book_qnt = $request->book_qnt;
        $book->book_image = $imgeUrl;
        $book->book_status = $request->book_status;
        $book->publication_status = $request->publication_status;

        $book->save();

        return redirect('/books/add-books')->with('message','Book Added Successfully');
    }

    public function manageBook(){
//        $books = Book::all();
//        return view('backEnd.admin.books.manage-books',[
//            'books' => $books
//        ]);
        $books = DB::table('books')
            ->join('categories','books.category_id','=','categories.id')
            ->select('books.*','categories.category_name')
            ->get();

        return view('backEnd.admin.books.manage-books',[
            'books' => $books
        ]);


    }

    public function unpublishedBook($id){
        $books = Book::find($id);
        $books->publication_status = 0;
        $books->save();

        return redirect('/books/manage-book')->with('message','Book Unpublished Successfully');
    }
    public function publishedBook($id){
        $books = Book::find($id);
        $books->publication_status = 1;
        $books->save();

        return redirect('/books/manage-book')->with('message1','Book Published Successfully');
    }



    public function editBook($id){
        $categories = Category::all();
        $books = Book::find($id);
        return view('backEnd.admin.books.edit-book',[
            'books'=> $books,
            'categories'=>$categories
        ]);
    }

    public function updateBook(Request $request){
        $book = Book::find($request->books_id);

        $book->category_id = $request->category_id;
        $book->book_name = $request->book_name;
        $book->author_name = $request->author_name;
        $book->book_id = $request->book_id;
        $book->book_description = $request->book_description;
        $book->book_price = $request->book_price;
        $book->book_qnt = $request->book_qnt;
        $book->book_status = $request->book_status;
        $book->publication_status = $request->publication_status;
        $book->save();

        return redirect('/books/manage-book')->with('message1', 'Book Edited Successfully');
    }

    public function deleteCategory($id){
        $books = Book::find($id);
        $books->delete();

        return redirect('/books/manage')->with('message', 'Book Deleted Successfully');
    }
}
