<?php

namespace App\Http\Controllers;

use App\Book;
use App\Category;
use Illuminate\Http\Request;
use DB;

class MainController extends Controller
{
    public function index(){
        $categories = Category::where('publication_status',1)->get();
//        $spcat = Category::where('publication_status',1)
//            ->skip(6)
//            ->take(50)
//            ->get();
//        $book_status = 'recent';
//        $recent = Book::where('book_status',$book_status)->where('publication_status',1)->get();
//        $book_status = 'recent';
        $bookshelf = Book::where('book_status','recent')->where('publication_status',1)->get();
        $bookshelf1 = Book::where('book_status','deal')->where('publication_status',1)->get();
        $bookshelf2 = Book::where('book_status','best_seller')->where('publication_status',1)->get();
        $bookshelf3 = Book::where('book_status','top_book')->where('publication_status',1)->get();
//        $books = Book::where('publication_status',1)->get();
        return view('frontEnd.home',[
//            'books'=> $books,
            'categories'=>$categories,
            'bookshelf' => $bookshelf,
            'bookshelf1' => $bookshelf1,
            'bookshelf2' => $bookshelf2,
            'bookshelf3' => $bookshelf3
//            'spcat'=> $spcat
        ]);
    }



    public function category($id){
        $books = Book::where('category_id',$id)->where('publication_status',1)->paginate(16);
        $categories = Category::where('id',$id)->where('publication_status',1)->get();
        return view('frontEnd.category',[
            'books'=> $books,
            'categories'=>$categories
        ]);
    }

    public function bookDetails($id){
        $books = Book::find($id);
        return view('frontEnd.productdetails',[
            'books' => $books
        ]);
    }


}
