<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LinkController extends Controller
{
    public function home(){
        return view('frontEnd.home');
    }

    public function about(){
        return view('frontEnd.about');
    }

    public function art(){
        return view('frontEnd.art');
    }

    public function bio_memories(){
        return view('frontEnd.bio&memoris');
    }

    public function business_finance(){
        return view('frontEnd.business&finance');
    }

    public function childrensBooks(){
        return view('frontEnd.childrensBooks');
    }

    public function contact(){
        return view('frontEnd.contact');
    }

    public function cookBooks(){
        return view('frontEnd.cookBooks');
    }

    public function drama(){
        return view('frontEnd.drama');
    }

    public function fiction_fantasy(){
        return view('frontEnd.fiction&fantasy');
    }

    public function health_fitness(){
        return view('frontEnd.health&fitness');
    }

    public function history(){
        return view('frontEnd.history');
    }

    public function horror(){
        return view('frontEnd.horror');
    }

    public function photography(){
        return view('frontEnd.photography');
    }

    public function productDetails(){
        return view('frontEnd.productdetails');
    }

    public function logout(){
        return view('frontEnd.logout');
    }
}
