<section class="marquee">
    <div class="container marquee_text">
        <marquee>welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Buy your favourite books &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; welcome to our bookshop &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Buy your favourite books</marquee>
    </div>
</section>

<section>
    <nav class="navbar navbar-expand-lg navbar-light custom_nav">
        <div class="container">
            <div class="logo_bar">
                <div class="site_logo">
                    <a class="navbar-brand" href="{{route('/')}}">
                        <img class="sitelogo" src="{{asset('/')}}frontEnd/images/Bookshop-Logo.png" alt="logo">
                    </a>
                </div>

                <div class="search_bar">
                    <form class="form-inline my-2 my-lg-0 mr-auto">
                        <input class="form-control mr-sm-2" type="search" size="30" placeholder="Search Here" aria-label="Search">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>

            <div class="nav_menu">
                <ul>
                    <li><a href="">Log In</a></li>
                    <li><a href="#"><span></span></a></li>
                    <li><a href="{{route('contact')}}">contact us</a></li>
                    <li><a href="{{route('about')}}">abouts us</a></li>
                </ul>
            </div>
            <div class="clr"></div>
        </div>
    </nav>
</section>
<!--  First Part End  -->

<!--  Second Part Start  -->
<section>
    <div class="menu_part">
        <div class="container">
            <div class="menu">
                <ul>
                    @foreach($categories as $category)
                        <li><a href="{{route('home-category',['id'=>$category->id])}}">{{$category->category_name}}</a></li>
                    @endforeach

                        {{--<li><a href="#">more&nbsp;&nbsp;<i class="fas fa-angle-down"></i></a>--}}
                            {{--<ul>--}}
                                {{--@foreach($spcat as $value)--}}
                                    {{--<li><a href="{{route('home-category',['id'=>$category->id])}}">{{$value->category_name}}</a></li>--}}
                                {{--@endforeach--}}
                            {{--</ul>--}}
                        {{--</li>--}}

                </ul>
            </div>
            <div class="clr"></div>
        </div>
    </div>
</section>