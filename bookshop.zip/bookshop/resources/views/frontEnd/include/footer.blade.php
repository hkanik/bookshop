<section>
    <div class="contact_part">
        <div class="container contact_part_inn">
            <div class="col-lg-3 contact_part_inn_contact">
                <h1>contact</h1>
                <h2>ashraf@bookshopbd.com<br>001 (407) 901-6400<br>Made in Bangladesh </h2>
                <a href="https://www.facebook.com/ashraf.siddiqui.abir" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/abir_siddiqui" target="_blank"><i class="fab fa-twitter"></i></a>
                <i class="fab fa-google-plus-g"></i>
            </div>

            <div class="col-lg-3 contact_part_inn_find">
                <h1>find</h1>
                <div class="contact_part_inn_find_items">
                    <h2>Columns</h2>
                    <h2>Recipes</h2>
                    <h2>Contents</h2>
                    <h2>Hotline</h2>
                    <h2>Shop</h2>
                    <h2>The piglet</h2>
                    <h2>Sitemap</h2>
                </div>
            </div>

            <div class="col-lg-3 contact_part_inn_shop">
                <h1>shop</h1>
                <div class="contact_part_inn_shop_items">
                    <h2>My Orders</h2>
                    <h2>Shop Cpllections</h2>
                    <h2>Gift Cards</h2>
                    <h2>Get Help</h2>
                    <h2>FAQ</h2>
                    <h2>Refer Friends, Get $20</h2>
                    <h2>Affilliate Program</h2>
                </div>
            </div>
        </div>
    </div>
</section>

<!--  Seventh Part End  -->


<!--  Eighth Part Start  -->

<section>
    <div class="footer_part">
        <div class="container footer_part_inn">
            <h1>Copyright 2019 &copy; bookshopbd.com</h1>
        </div>
    </div>
</section>

<!--  Eighth Part End  -->




<!--backtop start-->
<section>
    <div class="backtop">
        <i class="fas fa-arrow-up"></i>
    </div>
</section>