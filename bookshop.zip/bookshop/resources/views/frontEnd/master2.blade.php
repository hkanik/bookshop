<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bookshop- Books Category</title>
    <link rel="icon" href="{{asset('/')}}frontEnd/images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/fontawesome.all.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/booklist.css">
</head>

<body>
<!--  First Part Start  -->
@include('frontEnd.include.header')
<!--  Second Part End  -->

<!--  Third Part Start  -->
@yield('body')

<!--  Fourth Part End  -->

<!--  Fifth Part Start  -->

@include('frontEnd.include.footer')
<!--backtop end-->



<script src="{{asset('/')}}frontEnd/js/jquery-1.12.4.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/popper.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/bootstrap.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/slick.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/script.js"></script>
</body>

</html>