<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>BookShop</title>
    <link rel="icon" href="{{asset('/')}}frontEnd/images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/fontawesome.all.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/slick.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/style.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/productdetails.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/contact.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/about.css">
</head>


<style>
    body {
        background: rgba(0, 0, 0, 0.2);
    }
</style>


<body>

<!--    Preloader Start  -->


<!--
    <div class="preloader">
        <div class="preloader_inn">
            <img src="{{asset('/')}}frontEnd/images/google-151515.gif" alt="">
        </div>
    </div>
-->


<!--    Preloader End  -->

<!--  First Part Start  -->
@include('frontEnd.include.header')
<!--  Second Part End  -->

<!--  Third Part Start -->

@yield('body')

<!--  Sixth Part End  -->


<!--  Seventh Part Start  -->

@include('frontEnd.include.footer')
<!--backtop end-->




<script src="{{asset('/')}}frontEnd/js/jquery-1.12.4.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/popper.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/bootstrap.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/slick.min.js"></script>
<script src="{{asset('/')}}frontEnd/js/script.js"></script>
</body>

</html>
