<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bookshop";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }

    if(isset($_POST['submit']))
        {
            $username=$_POST['username'];
            $email=$_POST['email'];
            $userid=$_POST['userid'];
            $password=$_POST['password'];
            $cpassword=$_POST['cpassword'];

            if($password==$cpassword)
                {

                    $querry = "SELECT * FROM user_registration WHERE EMAIL='$email'";
                    $querry_run = mysqli_query($conn,$querry);

                    if(mysqli_num_rows($querry_run)>0)
                        {
                            header("location:error/mailexist.php");
                        }

                    else
                        {
                            $querry = "SELECT * FROM user_registration WHERE USER_NAME='$username'";
                            $querry_run = mysqli_query($conn,$querry);

                            if(mysqli_num_rows($querry_run)>0)
                                {
                                    header("location:error/username.php");
                                }
                            else
                            {
                                $sql = "INSERT INTO user_registration (USER_NAME, USER_EMAIL, USER_ID, PASSWORD) VALUES ('$username', '$email', '$userid','$password')";

                                if ($conn->query($sql) === TRUE)
                                    {
                                        header("location:login.blade.php");
                                    }

                                else
                                    {
                                        echo '<script type="text/javascript"> alert("Sign Up Failed")</script>';
                                    }
                            }
                        }
                }
            else
                {
                    header("location:passnotmatch.php");
                }
        }

    $conn->close();
?>
