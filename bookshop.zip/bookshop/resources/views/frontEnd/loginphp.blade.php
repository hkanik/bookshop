<?php
    session_start();
    $conn = mysqli_connect("localhost", "root", "", "bookshop");

    if(isset($_REQUEST['submit']))
    {
        $email = $_REQUEST['email'];
        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];

         $sql = "select * from user_registration where (USER_EMAIL='$email' AND USER_ID='$username') and PASSWORD='$password'";
         $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result) == 1)
            {
                $_SESSION['username']=$username;
                header("location:home.blade.php");
            }

        else
            {
                header("location:error/wrongmup.php");
            }
    }
?>
