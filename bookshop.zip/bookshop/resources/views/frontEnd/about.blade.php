  <!--    Preloader End  -->

    <!--  First Part Start  -->
    @extends('frontEnd.master')
    <!--  Second Part End  -->

    <!--  Third Part Start  -->
@section('body')
    <section>
        <div class="about">
            <div class="container">

                <div class="about_left">
                    <img src="{{asset('/')}}frontEnd/images/IMG_Abir.jpg" alt="">
                    <h1>Name: S. M. Ashraf Siddiqui</h1>
                    <h1>Daffodil International University</h1>
                </div>

                <div class="about_right">
                    <img src="{{asset('/')}}frontEnd/images/IMG_Urmi.jpg" alt="">
                    <h1>Name: Urmi Roy</h1>
                    <h1>Daffodil International University</h1>
                </div>

            </div>
            <div class="clr"></div>
        </div>
    </section>
@endsection
    <!--  Third Part End  -->

    <!--  Seventh Part Start  -->
