@extends('frontEnd.master2')

@section('body')
    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url({{asset('/')}}frontEnd/images/Books_507x313_SHP_Homepg.jpg)">
                <div class="container text-center">
                    <div class="col-lg-6 banner_text">

                        <div class="banner_text_inn">
                            @foreach($categories as $category)
                            <h2>{{$category->category_name}}</h2>
                                @endforeach
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--  Third Part End  -->


    <!--  Fourth Part Start  -->

    <section>
        <div class="container books">
                <div class="col-lg-12 books_inn_one">
                    @foreach($books as $book)
                    <div class="books_inn_one_inn">
                        <a href="{{route('book-details',['id'=>$book->id])}}">
                            <img src="{{asset($book->book_image)}}" alt="">
                        </a>
                        <h1>{{$book->book_name}}</h1>
                        <h2>{{$book->author_name}}</h2>
                        <h3>৳ {{$book->book_price}}</h3>
                    </div>
                    @endforeach
                </div>



        </div>
        <div style="margin-left: 45%;margin-bottom: 5%" >
            {{$books->links()}}
        </div>
    </section>
@endsection