@extends('frontEnd.master')

@section('body')
    <section>
        <div class="abtproduct">
            <div class="container abtproduct_inn">
                <div class="abtproduct_left">
                    <img src="{{asset($books->book_image)}}" alt="">
                </div>
                <div class="abtproduct_right">
                    
                    <h1>{{$books->book_name}}</h1>

                    <h2>by: {{$books->author_name}}</h2>

                    <h2>book ID: {{$books->book_id}}</h2>

                    <p>{{$books->book_description}}</p>

                    <h3> $ {{$books->book_price}}</h3>

                    <label>Quantity: </label>
                    <select>
                        <option>Select</option>

                            @for($i=1;$i<=5;$i++)
                            <option>{{$i}}</option>
                            @endfor

                    </select>
                    <br><br>
                    <input type="submit" value="add to cart">
                </div>
            </div>
        </div>
    </section>
@endsection
