<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bookshop - Sign Up</title>
    <link rel="icon" href="{{asset('/')}}frontEnd/images/books-icon.png">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/fontawesome.all.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/signup.css">
    <!-- <link rel="stylesheet" href="{{asset('/')}}frontEnd/css/responsive.css"> -->
</head>

<body>

    <!--    Preloader Start  -->

    <!--
    <div class="preloader">
        <div class="preloader-inn">
            <img src="{{asset('/')}}frontEnd/images/google-151515.gif" alt="">
        </div>
    </div>
-->

    <!--    Preloader End  -->


    <!--    Form Part Start   -->
    <section>
        <div class="banner_part">
            <div class="banner_item" style="background: url({{asset('/')}}frontEnd/images/thumb-1920-26102.jpg)">
                <div class="container">
                    <div class="banner_text">
                        <div class="banner_text_inn">
                            <form method="post">
                                @csrf

                                <h2>Sign Up</h2>

                                <input name="username" type="text" placeholder="User's Name" value="{{ old('username') }}" required><br><br>

                                <input name="email" type="email" placeholder="Email" value="{{ old('email') }}" required><br><br>

                                <input name="password" type="password" id="password" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least 1 number, 1 uppercase, 1 lowercase and at least 6 characters" maxlength="18" required><br>

                                <label for="checkbox">
                                    <input id="checkbox" type="checkbox" onclick="showPass()">Show Password
                                </label><br>

                                <input name="password_confirmation" type="password" id="cpassword" placeholder="Confirm Password" maxlength="18" required><br>

                                <label for="rcheckbox">
                                    <input id="rcheckbox" type="checkbox" onclick="showPassa()">Show Password
                                </label><br>

                                <input name="submit" type="submit" value="sign up">

                                <input type="reset" value="reset">

                                <h5>have an account? <a href="{{route('login')}}">log in</a> </h5>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    Form Part End   -->


    <!--  second Part Start  -->

    <section>
        <div class="contact_part">
            <div class="container contact_part_inn">
                <div class="col-lg-3 contact_part_inn_contact">
                    <h1>contact</h1>
                    <h2>ashraf@bookshopbd.com<br>001 (407) 901-6400<br>Made in Bangladesh </h2>
                    <a href="https://www.facebook.com/ashraf.siddiqui.abir" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/abir_siddiqui" target="_blank"><i class="fab fa-twitter"></i></a>
                    <i class="fab fa-google-plus-g"></i>
                </div>

                <div class="col-lg-3 contact_part_inn_find">
                    <h1>find</h1>
                    <div class="contact_part_inn_find_items">
                        <h2>Columns</h2>
                        <h2>Recipes</h2>
                        <h2>Contents</h2>
                        <h2>Hotline</h2>
                        <h2>Shop</h2>
                        <h2>The piglet</h2>
                        <h2>Sitemap</h2>
                    </div>
                </div>

                <div class="col-lg-3 contact_part_inn_shop">
                    <h1>shop</h1>
                    <div class="contact_part_inn_shop_items">
                        <h2>My Orders</h2>
                        <h2>Shop Cpllections</h2>
                        <h2>Gift Cards</h2>
                        <h2>Get Help</h2>
                        <h2>FAQ</h2>
                        <h2>Refer Friends, Get $20</h2>
                        <h2>Affilliate Program</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--  second Part End  -->


    <!--  Third Part Start  -->

    <section>
        <div class="footer_part">
            <div class="container footer_part_inn">
                <h1>Copyright 2019 &copy; bookshopbd.com</h1>
            </div>
        </div>
    </section>

    <!--  Third Part End  -->



    <!--backtop start-->
    <section>
        <div class="backtop">
            <i class="fas fa-arrow-up"></i>
        </div>
    </section>
    <!--backtop end-->


    <script type="text/javascript" src="{{asset('/')}}frontEnd/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="{{asset('/')}}frontEnd/js/slick.min.js"></script>
    <script type="text/javascript" src="{{asset('/')}}frontEnd/js/form.js"></script>
</body>

</html>
