<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dark Bootstrap Admin </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/vendor/font-awesome/css/fontawesome.all.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/{{asset('/')}}bacEnd/admin/css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="{{asset('/')}}bacEnd/admin/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="{{asset('/')}}bacEnd/admin/img/favicon.ico">
</head>

<body>
@include('backEnd.admin.includes.header')

<div class="d-flex align-items-stretch">
    <!-- Sidebar Navigation-->
    @include('backEnd.admin.includes.sidebar')
    <!-- Sidebar Navigation end-->
    <div class="page-content">
        @yield('body')

        @include('backEnd.admin.includes.footer')
    </div>
</div>
<!-- JavaScript files-->
<script src="{{asset('/')}}bacEnd/admin/vendor/jquery/jquery.min.js"></script>
<script src="{{asset('/')}}bacEnd/admin/vendor/popper.js/umd/popper.min.js"> </script>
<script src="{{asset('/')}}bacEnd/admin/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="{{asset('/')}}bacEnd/admin/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="{{asset('/')}}bacEnd/admin/vendor/chart.js/Chart.min.js"></script>
<script src="{{asset('/')}}bacEnd/admin/vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="{{asset('/')}}bacEnd/admin/js/charts-home.js"></script>
<script src="{{asset('/')}}bacEnd/admin/js/front.js"></script>
</body>
</html>
