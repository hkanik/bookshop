@extends('backEnd.admin.master')

@section('body')
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Edit Books Category</h2>
        </div>
    </div>

    <div class="col-lg-6 offset-lg-1" style="margin-top: 20px; ">
        <div>
            <div class="block-body">
                <form method="post" action="{{route('update-category')}}">
                    <h3 class="text-center text-warning">{{Session::get('message1')}}</h3>
                    @csrf
                    <div class="form-group">
                        <label class="form-control-label">Category Name</label>
                        <input type="text" name="category_name" class="form-control" value="{{$category->category_name}}" required>
                        <input type="hidden" name="category_id" class="form-control" value="{{$category->id}}">
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Category Description</label>
                        <textarea class="form-control" name="category_description" id="" cols="30" rows="5">{{$category->category_description}}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Publication Status</label> &nbsp;
                        <input type="radio" name="publication_status" value="1" required {{$category->publication_status == 1? 'checked':''}}> Published &nbsp;
                        <input type="radio" name="publication_status" value="0" required {{$category->publication_status == 0? 'checked':''}}> Unpublished
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" name="submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection