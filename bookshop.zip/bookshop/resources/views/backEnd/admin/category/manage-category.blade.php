@extends('backEnd.admin.master')

@section('body')
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Manage Books Category</h2>
        </div>
    </div>

    <div class="col-lg-10 offset-lg-1" style="margin-top: 20px; ">
        <h3 class="text-center text-success">{{Session::get('message1')}}</h3>
        <h3 class="text-center text-danger">{{Session::get('message')}}</h3>
        <table class="table">
            <tr>
                <th>Serial No.</th>
                <th>Category Name</th>
                <th>Category Description</th>
                <th>Publication Status</th>
                <th>Action</th>
            </tr>
            @php($i=1)
            @foreach($catagories as $category)
            <tr>
                <td>{{$i++}}</td>
                <td>{{$category-> category_name}}</td>
                <td>{{$category-> category_description}}</td>
                <td>{{$category-> publication_status == 1?'Published':'Unpublished'}}</td>
                <td>
                    @if($category->publication_status == 1)
                        <a href="{{route('unpublished-category',['id'=>$category->id])}}" class="btn btn-success">
                            <i class="fas fa-arrow-up"></i>
                        </a>
                    @else
                        <a href="{{route('published-category',['id'=>$category->id])}}" class="btn btn-danger">
                            <i class="fas fa-arrow-down"></i>
                        </a>
                    @endif
                    <a href="{{route('edit-category',['id'=>$category->id])}}" class="btn btn-info">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="{{route('delete-category',['id'=>$category->id])}}" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
                @endforeach
        </table>
    </div>

@endsection