<footer class="footer">
    <div class="footer__block block no-margin-bottom">
        <div class="container-fluid text-center">
            <p class="no-margin-bottom">Copyright 2019 &copy; bookshopbd.com</p>
        </div>
    </div>
</footer>