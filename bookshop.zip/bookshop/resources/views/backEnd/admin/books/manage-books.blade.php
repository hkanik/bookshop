@extends('backEnd.admin.master')

@section('body')
    <div class="page-header">
        <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Manage Books</h2>
        </div>
    </div>

    <div class="col-lg-12" style="margin-top: 20px; ">
        <h3 class="text-center text-success">{{Session::get('message1')}}</h3>
        <h3 class="text-center text-danger">{{Session::get('message')}}</h3>
        <table class="table">
            <tr>
                <th>Serial No.</th>
                <th>Category Name</th>
                <th>Book Name</th>
                <th>Author Name</th>
                <th>Book Id</th>
                <th>Book Description</th>
                <th>Book Price</th>
                <th>Book Quantity</th>
                <th>Publication Status</th>
                <th>Action</th>
            </tr>
            @php($i=1)
            @foreach($books as $book)
            <tr>
                <td>{{$i++}}</td>
                <td>{{$book-> category_name}}</td>
                <td>{{$book-> book_name}}</td>
                <td>{{$book-> author_name}}</td>
                <td>{{$book-> book_id}}</td>
                <td>{{$book-> book_description}}</td>
                <td>{{$book-> book_price}}</td>
                <td>{{$book-> book_qnt}}</td>
                <td>{{$book-> book_status}}</td>
                <td>{{$book-> publication_status == 1?'Published':'Unpublished'}}</td>
                <td>
                    @if($book->publication_status == 1)
                        <a href="{{route('unpublished-book',['id'=>$book->id])}}" class="btn btn-success">
                            <i class="fas fa-arrow-up"></i>
                        </a>
                    @else
                        <a href="{{route('published-book',['id'=>$book->id])}}" class="btn btn-danger">
                            <i class="fas fa-arrow-down"></i>
                        </a>
                    @endif
                    <a href="{{route('edit-book',['id'=>$book->id])}}" class="btn btn-info">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="{{route('delete-book',['id'=>$book->id])}}" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
                @endforeach
        </table>
    </div>

@endsection